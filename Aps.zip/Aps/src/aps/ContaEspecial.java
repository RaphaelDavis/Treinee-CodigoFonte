package aps;

import javax.swing.JOptionPane;

public class ContaEspecial extends Conta {
		
		private double limite=500;
		
		//construtor defaut
		public ContaEspecial() {
			super();
		}
		
		//sobrecarga do construtor
		public ContaEspecial(int numero, Cliente end) {
			super(numero, end);
		}
		
		//gets e sets
		public double getLimite() {
			return limite;
		}

		public void setLimite(double limite) {
			this.limite = limite;
		}
		
		//metodo sacar
		public boolean sacar(double quantia) {
			boolean cond;
			double saldoEspecial=super.getSaldo()+limite;
			if(super.getQuantia()>saldoEspecial) {
				cond=false;
                                JOptionPane.showMessageDialog(null,"Não é possivel sacar a quantia solicitada");
			}else {
				cond=true;
                                if((saldoEspecial-quantia)>=0){
                                    
                              
                                super.setSaldo(super.getSaldo()-quantia); 
                                  }else{
                                    JOptionPane.showMessageDialog(null,"Não é possivel sacar a quantia solicitada");
                                }
			}
			
			return cond;
		}
		
		public String imprimir() {
			return super.imprimir()+
				"Limite: "+limite+"\n";
		}		
}
