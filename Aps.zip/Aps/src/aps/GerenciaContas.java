/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aps;

import java.util.ArrayList;


/**
 *
 * @author rockt
 */
public class GerenciaContas {
    private static ArrayList<Conta> list = new ArrayList();
    
     public static ArrayList<Conta> getList() {
        return list;
    }
     
    public static void setList(ArrayList<Conta> list) {
        GerenciaContas.list = list;
    }
 
    static void cadastrar(Conta con){
        list.add(con);    
    }
    static void cadastrarEspecial(ContaEspecial con){
        list.add(con);    
    }
    static String listarContas(){
        String saida = "";
        if(list.isEmpty()){
            saida+="Nenhuma conta cadastrada";
        }else{
            for(Conta con: list ){
                saida+=con.imprimir()+"\n*********//*********\n";
            }
        }
    return saida;
    }

static String buscarConta(int num){
        String saida = "";
        if(list.isEmpty()){
            saida+="Nenhuma conta cadastrada para fazer a busca";
        }else{
            for(Conta con: list ){
                if(num == con.getNumero()){
                saida+=con.imprimir();
                }
            }
             }
   return saida;
}

    static double depositar2(int num, double quantia){
        double dep = 0;
      
            for(Conta con: list ){
                if(num == con.getNumero()){
                    con.depositar(quantia);
                    dep=con.getSaldo();
                con.setSaldo(dep);
                }
            }
       
   
    return dep;
    }
 static double sacar2(int num, double quantia){
        double dep = 0;
      
            for(Conta con: list ){
                if(num == con.getNumero()){
                    con.sacar(quantia);
                    dep=con.getSaldo();
                con.setSaldo(dep);
                }
            }
       
   
    return dep;
    }

}
         
 /*private int numero;
	private double saldo=0;
	private double quantia=0;
	private Cliente end;*/





       
