/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aps;

/**
 *
 * @author Aluno P2
 */
public class APS {
    
    public static void bubleSort(int[] vet){
        int a = vet.length;
        int meio;
        for(int i = 0; i<a; i++){
            for(int j = 0; j<a-1; j++){
                
                if(vet[j]>vet[j+1]){
                    meio = vet[j];
                    vet[j] = vet[j+1];
                    vet[j+1] = meio;
                }
            }
        }
    }
    
    public static void bubleSort2(int[] vet){
        int a = vet.length;
        int meio;
        boolean invertido;
        do{
            invertido = false;
            for(int j = 0; j<a-1; j++){
                
                if(vet[j]>vet[j+1]){
                    meio = vet[j];
                    vet[j] = vet[j+1];
                    vet[j+1] = meio;
                    invertido = true;
                }
            }
        }while(invertido  == true);
    }
    
    public static void bubleSort3(int[] vet){
        int a = vet.length;
        int meio;
        int n;
        boolean invertido;
        do{
            n = 0;
            for(int j = 0; j<a-1; j++){
                
                if(vet[j]>vet[j+1]){
                    meio = vet[j];
                    vet[j] = vet[j+1];
                    vet[j+1] = meio;
                    invertido = true;
                    n=j;
                }
            }
        }while(n > 0);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] teste = {5,4,6,1,2,3,8,10,9};
        bubleSort3(teste);
        for(int i = 0; i<teste.length; i++){
            System.out.println(teste[i]);
        }
        
    }
    
}
