package aps;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conta {
    private Connection cnn;

	private int numero;
	private double saldo=0;
	private double quantia=0;
	private Cliente end;
	private static ArrayList<Conta> list = new ArrayList();
	
//contrutor default
	
	//sobrecarga do contrutor
	

        public Conta(int numero, Cliente end) {
            this.numero = numero;
            this.end = end;
        }

    Conta() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
	
	//gets e sets
	public void setNumero(int numero) {
		this.numero=numero;
	}
	
	public int getNumero() {
		return numero;
	}
	
	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public double getQuantia() {
		return quantia;
	}

	public void setQuantia(double quantia) {
		this.quantia = quantia;
	}
	
	public Cliente getEnd() {
		return end;
	}

	public void setEnd(Cliente end) {
		this.end = end;
	}
	
	//metodo depositar
	public void depositar(double quantia) {
		saldo = saldo+quantia;
	
        }
        
	
	
	//metodo sacar
	public boolean sacar(double quantia) {
		boolean cond;
		if(quantia>saldo) {
			cond=false;
                        JOptionPane.showMessageDialog(null,"Não é possivel sacar a quantia solicitada");
		}else {
			cond=true;
                        saldo = saldo - quantia;
		}
		
		return cond;
	}
	
	public String imprimir() {
		return "Nome: "+end.getNome()+
			   "\nCPF: "+end.getCpf()+
			   "\nNumero da conta: "+numero+
			   "\nSaldo: "+saldo+"\n";				
	}

    private static class RutimeException extends Exception {

        public RutimeException() {
        }

        private RutimeException(SQLException e) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }

	

	
	
	

}
